Got To Vote! by Code4Kenya
==========================

This is a website to help people to easily find registration centres in Kenya. This is done using scraped data from the IEBC published PDF on registration centres.