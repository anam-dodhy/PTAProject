function TreeNode(data, parent, isAsync) {
        this.data = data;
        this.parent = parent;
        this.children = [];
        this.xhrObject = null;
        this.isAsync = isAsync;
    }

    TreeNode.prototype.traverseDF = function () {
        function recurse(currentNode) {
            for (var i = 0; i < currentNode.children.length; i++) {
                recurse(currentNode.children[i]);
            }
            if(currentNode.isAsync){
                console.log("anonymous");
            }else{
                console.log(currentNode.data.name);
            }
            
        }

        recurse(this);
    };

    TreeNode.prototype.findNode = function (data) {
        function recurse(currentNode) {
            if (currentNode.data.prototype == data.prototype) {
                return currentNode;
            } else {
                var i;
                var result = null;
                for (i = 0; result == null && i < currentNode.children.length; i++) {
                    result = recurse(currentNode.children[i]);
                }
                return result;
            }
        }

        return recurse(this);
    };

    TreeNode.prototype.addChild = function (child) {
        this.children.push(child);
        child.parent = this;
};
