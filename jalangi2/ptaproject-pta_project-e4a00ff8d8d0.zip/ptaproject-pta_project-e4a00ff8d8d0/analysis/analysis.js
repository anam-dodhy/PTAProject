(function (sandbox) {
    var branches = {};

    function MyAnalysis() {

        var roots = [];
        var printed = false;
        var currentNode = null;
        var exceptionAlreadyThrown = false;


        /**
         * Tree class for saving callstack
         * @param data function to save
         * @param parent
         * @param isAsync
         * @param iid
         */
        function TreeNode(data, parent, isAsync, iid) {
            this.data = data;
            this.iid = iid;
            this.parent = parent;
            this.children = [];
            this.xhrObject = null;
            this.isAsync = isAsync;
            this.funcBody = null;
            this.name = null;
            if (!isAsync) {
                this.name = data.name;
            } else {
                this.name = "anonymous";
            }
        }

        TreeNode.prototype.traverseDF = function () {
            function recurse(currentNode) {
                for (var i = 0; i < currentNode.children.length; i++) {
                    recurse(currentNode.children[i]);
                }
            }

            recurse(this);
        };

        /**
         * Finds tree node in callstack hierarchy using DepthFirst search
         * @param data function to find
         * @returns {*}
         */
        TreeNode.prototype.findNode = function (data) {
            function recurse(currentNode) {

                if (currentNode.data === data || currentNode.funcBody === data) {
                    return currentNode;
                } else {
                    var i;
                    var result = null;
                    for (i = 0; result == null && i < currentNode.children.length; i++) {
                        result = recurse(currentNode.children[i]);
                    }
                    return result;
                }
            }

            return recurse(this);
        };

        TreeNode.prototype.findAsyncNode = function (func) {
            function recurse(currentNode) {

                if (currentNode.funcBody != null && currentNode.funcBody.prototype === func.prototype) {
                    return currentNode;
                } else {
                    var i;
                    var result = null;
                    for (i = 0; result == null && i < currentNode.children.length; i++) {
                        result = recurse(currentNode.children[i]);
                    }
                    return result;
                }
            }

            return recurse(this);
        };


        TreeNode.prototype.addChild = function (child) {
            this.children.push(child);
            child.parent = this;
        };


        /**
         * Prints whole hierarchy of `tempPrintNode`
         * @param tempPrintNode
         */
        function printStackTrace(tempPrintNode) {
            while (tempPrintNode != null) {
                var lineNo = J$.iidToLocation(J$.sid, tempPrintNode.iid).split(":")[3];
                //var name = tempPrintNode.name == "F" ? "anonymous" : tempPrintNode.name;
                name = tempPrintNode.name;
                console.log("function:" + name + " OffsetNo:" + lineNo);
                tempPrintNode = tempPrintNode.parent;
            }

        }

        //used when setTimeout function is called.
        this.invokeFunPre = function (iid, f, base, args, isConstructor, isMethod, functionIid, functionSid) {
            if (f.name != "setTimeout") {
                if (args[0] != null) {
                    args[0].callerFun = null;
                }
                return;
            }
            //saving current node in function's reference to link asynchronous function with currentNode i.e. the
            //function calling setTimeout
            args[0].callerFun = currentNode;
        };


        this.functionEnter = function (iid, f, dis, args) {

            //if the function entered is anonymous
            if (f.name === "") {
                //if the function object has the callerFun field set
                //happens only when async function was passed to setTimeOut
                if (f.hasOwnProperty("callerFun") && f.callerFun != null) {
                    var n = new TreeNode(args[0], f, true, iid);
                    n.name = "anonymous";
                    f.callerFun.addChild(n);
                    currentNode = n;
                }
                //Async function due to AJAX call.
                else {
                    var node = null;
                    for (root in roots) {
                        node = roots[root].findAsyncNode(f);
                        if (node != null) {
                            currentNode = node;
                            break;
                        }
                    }
                    //node not found, new root node
                    if (node === null) {
                        var t = new TreeNode(f, null, true, iid);
                        t.name = "anonymous";
                        roots.push(t);
                        currentNode = t;
                    }
                }
                return;
            }
            //is not async function.
            
            newNode = new TreeNode(f, currentNode, false, iid);
            //add a new root node
            if (currentNode === null) {
                currentNode = newNode;
                roots.push(newNode);
            }
            //currentNode is not null so add as child to currentNode
             else {
                currentNode.addChild(newNode);
                currentNode = newNode;
            }

        };

        this.functionExit = function (iid, returnVal, wrappedExceptionVal) {
        	//if the function exits because of an exception
            if (wrappedExceptionVal != null && typeof(wrappedExceptionVal) != 'undefined'
                && typeof(wrappedExceptionVal.exception) != 'undefined') {
            	//Jalangi calls functionExit twice in case of exception
            	//we want to print stacktrace only once, hence the check
                if (!exceptionAlreadyThrown) {
                    exceptionAlreadyThrown = true;
                    var lineNo = J$.iidToLocation(J$.sid, iid).split(":")[3];

                    if (!printed) {
                        console.log("Error occurred at offset: " + lineNo);
                        console.log("Stacktrace:");
                        printStackTrace(currentNode);

                    }
                    printed = !printed;

                } else {
                    exceptionAlreadyThrown = false;
                }
            }
            if (currentNode != null && currentNode.parent != null) {
                currentNode = currentNode.parent;
            }
        };


        //Saving anonymous functions for creating stracktrace for ajax calls
        this.putFieldPre = function (iid, base, offset, val, isComputed, isOpAssign) {
            //if the field was "onreadystatgechange"
            //if the base object is AJAX request type object
            if (base != null && offset + "" === "onreadystatechange"
                && Object.prototype.toString.call(base) === "[object XMLHttpRequest]") {
                var asyncNode = new TreeNode("\tanonymous", currentNode, true, iid);
                asyncNode.funcBody = val;
                asyncNode.xhrObject = base;
                currentNode.addChild(asyncNode);
            }
        };


    }

    sandbox.analysis = new MyAnalysis();
}(J$));