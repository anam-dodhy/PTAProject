How to deploy GoToVote:
=======================
Go to vote is simple HTML/javascript project and can be easily deployed on any local server.

How to reproduce Ajax Stacktrace
===============================
Deploy GoToVote -> Select country from drop down -> Stacktrace can be seen on console

How to reproduce SetTimeOut error
===============================
Uncomment following line in js/main.js file
window.onload = function () {
    //wardChangedWithTimeOut();
}

wardChangedWithTimeOut is calling other functions which in the end throws exception

How to run mitmproxy on Linux:
===============================
mitmdump --quiet --anticache -s "scripts/proxy.py --inlineIID --inlineSource --analysis src/js/sample_analyses/ChainedAnalyses.js --analysis src/js/runtime/analysisCallbackTemplate.js"

How to run mitmproxy on Mac:
===============================
./scripts/mitmproxywrapper.py --toggle --auto-disable --quiet --anticache -s "scripts/proxy.py --inlineIID --inlineSource --analysis src/js/sample_analyses/ChainedAnalyses.js --analysis src/js/runtime/analysisCallbackTemplate.js"

